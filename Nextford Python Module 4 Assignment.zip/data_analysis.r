# Netflix Movies and Shows Analysis

# import tidyverse and lubridate
library(tidyverse)
library(lubridate)

# Step 1: Process data
process_data <- function(file_path) {
  netflix_df <- read_csv(file_path)
  print(colSums(is.na(netflix_df)))
  
  # Clean the data
  netflix_df <- netflix_df %>%
    mutate(
      director = replace_na(director, "Not Available"),
      cast = replace_na(cast, "Not Available"),
      country = replace_na(country, "Unknown"),
      rating = replace_na(rating, names(which.max(table(rating)))),
      date_added = mdy(str_trim(date_added)),
      date_added = replace_na(date_added, median(date_added, na.rm = TRUE))
    )
  
  # After cleaning
  print(colSums(is.na(netflix_df)))
  
  return(netflix_df)
}

# Function to analyze data
analyze_data <- function(df) {
  print(str(df))
  print(summary(df))
}

# Step 2: Visualize the data
visualize_data <- function(df) {
  df %>%
    separate_rows(listed_in, sep = ", ") %>%
    count(listed_in, sort = TRUE) %>%
    top_n(10) %>%
    ggplot(aes(x = reorder(listed_in, n), y = n)) +
    geom_bar(stat = "identity", fill = "skyblue") +
    coord_flip() +
    labs(title = "Top 10 Netflix Genres", x = "Genre", y = "Count") +
    theme_minimal()
  ggsave("visualization.png", width = 10, height = 6)
}

# Main
main <- function() {
  netflix_df <- process_data("Netflix_shows_movies.csv")
  analyze_data(netflix_df)
  visualize_data(netflix_df)
  cat("Analysis completed successfully.")
}

# Run the main function
main()
