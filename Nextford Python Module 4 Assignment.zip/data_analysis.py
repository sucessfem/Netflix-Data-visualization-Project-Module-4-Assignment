import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def process_data(file):
    # Step 1: Get the data
    netflix_df = pd.read_csv(file)
    print("Missing values before cleaning:")
    print(netflix_df.isnull().sum())

    # Step 2: Data cleaning
    netflix_df['director'].fillna('NA', inplace=True)
    netflix_df['cast'].fillna('NA', inplace=True)
    netflix_df['country'].fillna('NA', inplace=True)
    netflix_df['rating'].fillna(netflix_df['rating'].mode()[0], inplace=True)
    netflix_df['date_added'] = pd.to_datetime(netflix_df['date_added'].str.strip(), format='%B %d, %Y', errors='coerce')
    netflix_df['date_added'].fillna(netflix_df['date_added'].mode()[0], inplace=True)

    # Step: Convert the necessary data types
    type_mapping = {
        'show_id': 'string',
        'type': 'category',
        'title': 'string',
        'director': 'string',
        'cast': 'string',
        'country': 'string',
        'release_year': 'int',
        'rating': 'category',
        'duration': 'string',
        'listed_in': 'string',
        'description': 'string'
    }
    netflix_df.astype(type_mapping)
    
    # After cleaning
    print("\nMissing values after cleaning:")
    print(netflix_df.isnull().sum())
    return netflix_df

def analyze_visualize(df):
    
    print(df.info())
    print(df.describe())
    
    # Visualize Top producing countries
    plt.figure(figsize=(12, 6))
    country_data = df['country'].str.split(', ', expand=True).stack().value_counts().head(10)
    sns.barplot(x=country_data.index, y=country_data.values)
    plt.title('Top 10 Countries Producing Netflix Content')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.savefig('netflix_top_producing_countries.png')
    plt.close()
    
    # Visualize the top genres
    plt.figure(figsize=(12, 6))
    genre_data = df['listed_in'].str.split(', ', expand=True).stack().value_counts().head(10)
    sns.barplot(x=genre_data.index, y=genre_data.values)
    plt.title('Top 10 Netflix Genres')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.savefig('netflix_top_genres.png')
    plt.close()

    # Visualize the Content types
    plt.figure(figsize=(8, 6))
    df['type'].value_counts().plot(kind='pie', autopct='%1.1f%%')
    plt.title('Netflix Content Type Distribution')
    plt.ylabel('')
    plt.savefig('netflix_content_type_distribution.png')
    plt.close()

    # Visualize the rating
    plt.figure(figsize=(10, 6))
    sns.countplot(x='rating', data=df, order=df['rating'].value_counts().index)
    plt.title('Netflix Content Ratings Distribution')
    plt.xlabel('Rating')
    plt.ylabel('Count')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.savefig('netflix_ratings_distribution.png')
    plt.close()
   
def main():
    netflix_df = process_data('Netflix_shows_movies.csv')
    analyze_visualize(netflix_df)
    print("Analysis completed successfully")

if __name__ == "__main__":
    main()
